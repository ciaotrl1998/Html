# Biped Builder 1.1 · Blender Rigify 控制器版

控制层已改为 **Blender 自带 Rigify**：真实的 `hand_ik.L/R`、`foot_ik.L/R`、肘膝 Pole、脚掌滚动，以及 Root、Torso、Hips、Chest 控制器。蒙皮层继续使用 `Bip001 L UpperArm` 等 Biped 名称。新角色不再使用 1.0 的自建 IK 系统。

手脚默认全部启用 IK。Rigify 的混合属性为 **0 = IK，1 = FK**。

## 安装或升级

1. 先保存 Blender 文件，在「编辑 → 偏好设置 → 插件」停用旧版 Biped Builder。
2. 用「从磁盘安装 / Install from Disk」安装 `dist/Biped_Builder_1.1.0.zip` 并启用。若 Blender 仍缓存旧模块，重启一次。
3. 在 3D 视图按 `N`，打开 `Biped` 标签。

这是本地传统插件 ZIP。生成时会启用当前 Blender 安装中的 Rigify，不会写入用户偏好设置文件。若安装中没有 Rigify，需先在 Blender 的插件设置中安装 / 启用它。

主要针对 Blender 5.2；最低版本声明为 4.2，未安装的版本不作实测保证。新实测记录见 `dist/rigify_tests_*.json`。

## 已有旧骨架

**安装新版不会改变已经生成的旧骨架。**

1. 选中旧控制骨架。
2. 在「Biped → 动画 · IK / FK」点击 **从旧骨架重建 Rigify**。
3. 插件从保留的体型生成新的 Rigify，隐藏旧骨架，选中新角色并进入姿态模式。

旧骨架、动作和蒙皮均保留。已有网格仍绑定旧骨架，确认效果后可在网格副本中将骨架修改器指向新骨架；对应 Bip 名称和静置姿势应保持一致。旧版 `CTRL_...` 动画不会自动迁移到 Rigify 控制器。

原始体型被删除或关节未接合时，需要修复或新建体型。

## 创建新角色

1. 设置高度、骨节和姿势，或使用「标准人体 / 游戏 / 截图」预设。
2. 点击「① 创建体型骨架」，在编辑模式移动关节贴合模型。
3. 保持四肢关节接合，保留轻微肘膝弯曲，不要将整条肢体拉成完全共线。
4. 点击「② 生成控制骨架」，生成真实 Rigify 控制器并进入姿态模式。

角色正面为 `-Y`，上方为 `+Z`，左侧为 `+X`。高度以厘米输入，尊重场景单位比例。参数用于新建体型，不会覆盖手工调整；返回体型后再生成会建立另一套成品。

## 操作 IK

点击「动画 · IK / FK → 选择控制骨架」，确认模式为 **姿态模式 / Pose Mode**。

| 控制器 | 操作 |
| --- | --- |
| `hand_ik.L / .R` | G 移动手部目标，整条手臂跟随；R 旋转手掌 |
| `foot_ik.L / .R` | G 移动脚部目标，整条腿跟随；R 旋转脚 |
| `upper_arm_ik_target.L / .R` | 移动肘部方向控制器 |
| `thigh_ik_target.L / .R` | 移动膝部方向控制器 |
| `foot_heel_ik.L / .R` | 旋转脚掌 / 脚跟控制器，进行脚掌滚动 |
| `root` | 移动、旋转整个角色，包括手脚 IK |
| `torso` | 移动身体，IK 手脚默认保持原位 |
| `hips / chest / neck / head` | 调整骨盆、胸部、颈部和头部 |
| `..._fk.L / .R` | FK 模式下逐节旋转四肢 |

面板提供「手 IK」「脚 IK」「肘方向」「膝方向」选择按钮，准确选中后按 G。脚掌滚动按钮选择原生 Rigify 脚跟控制器，不再使用旧版 `foot_roll` 属性。

**0 = IK，1 = FK**，与旧版方向不同。「匹配 → IK / FK」使用当前安装的 Rigify 匹配逻辑对齐姿势后切换；直接拖混合滑条只做混合，不自动匹配。

只操作可见的 Rigify 线框控制器。`Bip...` 为蒙皮骨，默认隐藏且不可选；`ORG-`、`MCH-`、`DEF-` 是 Rigify 内部骨，不用于直接操作。

FK 集合初始隐藏，切换到 FK 或点击 FK 选择按钮后显示。微调集合也初始隐藏，可在「蒙皮、显示与烘焙 → 骨骼集合显示」打开。

插件中文面板在未执行 `.blend` 内嵌 UI 脚本时也可完成选择、IK/FK 匹配和切换；它使用本机 Rigify 的代码，不执行文件中的脚本，不修改脚本信任设置。Rigify 自带的 Rig Main Properties 面板也可使用。

## 骨节与命名

支持手臂开关、颈部 1–25 节、脊椎 1–10 节、腿 3 / 4 节、尾部 0–25 节、两组马尾各 0–25 节、手指 0–5 根且各 1–4 节、短拇指、脚趾 1–5 根且各 1–3 节、三组道具、T / A Pose、肩宽、髋宽、臂长和踝部附着。

「截图」预设：高度 315.52 厘米、脊椎 4、颈部 1、腿 3、手指 1 × 1、脚趾 1 × 3、踝部附着 0.2；三角形骨盆开启、三角形颈部关闭。

体型镜像使用插件「左 → 右 / 右 → 左」按钮。Bip 侧标使用 ` L ` / ` R `，不要依赖 Blender 的 `.L / .R` 名称镜像。

标准蒙皮骨示例：

```text
Bip001
Bip001 Pelvis
Bip001 Spine / Spine1 / Spine2 / Spine3
Bip001 Neck / Neck1 ...
Bip001 Head
Bip001 L Clavicle
Bip001 L UpperArm / Forearm / Hand
Bip001 L Finger0 / Finger01 / Finger02
Bip001 L Finger1 / Finger11 / Finger12
Bip001 L Thigh / Calf / Foot
Bip001 L Toe0 / Toe01 / Toe02
Bip001 R ...
Bip001 Tail / Tail1 ...
Bip001 Ponytail1 / Ponytail11 ...
Bip001 Prop1 / Prop2 / Prop3
```

Rigify 的 `DEF-` 不参与蒙皮，真正的蒙皮骨仅为原始 Bip 骨。跟随层保留静置方向差异，避免 Rigify 自动调整 Roll 后让 Bip 骨翻转。

一节脊椎使用 Rigify FK 身体链；至少两节脊椎时生成 Torso / Hips / Chest。四节兽腿使用 Rigify Paw；尾部、马尾、道具使用 Rigify FK。人体两节肢体是主要操作目标。

## 蒙皮、动画与导出

选择未绑定骨架的网格，在面板指定新 Rigify 角色，点击「自动权重绑定所选网格」。仅为 Bip 骨建立顶点组；已有骨架修改器的网格会被拒绝，请先在副本中处理。自动权重仍需检查和修整。

「整套姿势打关键帧」记录 Rigify 控制器和数值自定义属性。「重置整套姿势」恢复变换并将手脚设回 IK，不删除已有动画。

按时间轴起止帧「烘焙纯 Bip 动画骨架」，会创建新的纯 Bip 骨架及逐帧动作，包含 Root 运动，不含控制器和约束。原始网格仍绑定原控制骨架；导出皮肤网格时需在副本中改用烘焙骨架。FBX 可关闭 Add Leaf Bones。

本插件不读取 Max `.bip` 文件，不含 Character Studio Footstep 或自动重心平衡。同名不代表轴向和动画控制器数据与 Max 完全兼容。

## 示例与验证

- 新示例：`dist/Biped_Rigify_1.1_Demo.blend`。先启用插件再打开文件，选中新角色，在姿态模式操作。1–48 帧演示手部 IK、下蹲和脚掌滚动。
- `tests/rigify_integration.py`：用真实控制器选择及 `bpy.ops.transform.translate` 验证 G 移动、Bip 跟随、IK/FK 匹配、脚部锁定、膝方向、烘焙、自动权重和旧版重建。
- `tests/rigify_reload.py`：新进程禁用内嵌脚本后重开示例，检查 IK 与匹配。
- `tests/install_smoke.py`：隔离目录安装 ZIP 并生成 Rigify。
- `rigify_tests_*.json` 是 1.1 新记录。`test_results_*.json` 与 `Biped_Builder_Demo.blend` 是 1.0 留档，不代表新版测试。

参考：[Blender Rigify 官方组件](https://docs.blender.org/manual/en/5.2/addons/rigify/rig_types/index.html)、[Autodesk Biped 骨节设置](https://help.autodesk.com/cloudhelp/2024/ENU/3DSMax-Character-Animation/files/GUID-4C763A71-2ACE-4B75-8F33-4521C39D9E20.htm)。
